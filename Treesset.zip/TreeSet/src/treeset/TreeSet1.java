/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package treeset;
import java.util.*; 

/**
 *
 * @author Sala_11
 */
public class TreeSet1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

       TreeSet<Persona> personas = new TreeSet<Persona>();
       int id, contacto, peso;
       String nombre;
       float estatura;
       double imc;
       
       Scanner sc = new Scanner(System.in);
       
        do {        
            System.out.println("Eliga una opcion: \n" +
                    "1. Insertar elementos \n"+
                    "2. Consultar el primer elemento \n"+
                    "3. Consultar el ultimo elemento \n"+
                    "4. Eliminar al inicio \n"+
                    "5. Eliminar al final \n"+
                    "6. Buscar \n"+
                    "7. Contar la cantidad de elementos \n"+
                    "8. Salir \n");
            int o = sc.nextInt();
            switch(o)
            {
                case 1:
                    System.out.println("Digite id");
                    id = sc.nextInt();
                    System.out.println("Digite nombre");
                    nombre = sc.next();
                    System.out.println("Digite contacto");
                    contacto = sc.nextInt();
                    System.out.println("Digite peso");
                    peso = sc.nextInt();
                    System.out.println("Digite estatura");
                    estatura = sc.nextFloat();
                    imc = peso / (estatura*estatura);
                    personas.add(new Persona(id, nombre, contacto, peso, estatura, imc));
                    break;
                case 2: 
                    System.out.println(personas.first().toString());
                    break;
                case 3:
                    break;
            }
            
        } while (true);
       
       
    }
    
}
