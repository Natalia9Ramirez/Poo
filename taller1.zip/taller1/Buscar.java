/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller1;
/**
 *
 * @author Natalia.RamirezA
 */
public class Buscar {

    private char caracter;
    private String datos;

    public Buscar(char caracter, String datos) {
        this.caracter = caracter;
        this.datos = datos;
    }

    /**
     * @return the caracter
     */
    public char getCaracter() {
        return caracter;
    }

    /**
     * @param caracter the caracter to set
     */
    public void setCaracter(char caracter) {
        this.caracter = caracter;
    }

    /**
     * @return the datos
     */
    public String getDatos() {
        return datos;
    }

    /**
     * @param datos the datos to set
     */
    public void setDatos(String datos) {
        this.datos = datos;
    }

    void Busca() {
        int encontrado = 0;
        int i = 0;
        String acum = "", acum2 = "";
        for (i = 0; i < getDatos().length() && encontrado == 0; i++) {
            if (getDatos().charAt(i) == getCaracter()) {
                System.out.println("El dato fue encontrado en la posición:" + i);
                encontrado = 1;
            }
        }
        for (int j = i; j < getDatos().length(); j++) {
            acum = acum + getDatos().charAt(j);
        }
        for (int k = 0; k <= i - 2; k++) {
            acum2 = acum2 + getDatos().charAt(k);
        }
        System.out.println("Nombre: " + acum + " " + acum2);
    }
}
